import pandas as pd
import requests
from bs4 import BeautifulSoup
import os

# Function to extract the title and text of an article from a URL
def extract_article(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    # Assuming the title is within an <h1> tag
    title_tag = soup.find('h1')
    title = title_tag.get_text() if title_tag else 'No Title'

    # Assuming article text is within <p> tags
    paragraphs = soup.find_all('p')
    text = ' '.join([para.get_text() for para in paragraphs])

    return title, text

# Load input data
input_data = pd.read_excel('Input.xlsx')

# Create an output directory if it doesn't exist
output_dir = 'extracted_articles'
os.makedirs(output_dir, exist_ok=True)

# Iterate over each row in the input data
for index, row in input_data.iterrows():
    url_id = row['URL_ID']
    url = row['URL']

    try:
        title, text = extract_article(url)
        article_content = title + '\n' + text

        # Save the extracted content to a text file
        with open(os.path.join(output_dir, f'{url_id}.txt'), 'w', encoding='utf-8') as file:
            file.write(article_content)
        print(f'Successfully extracted article {url_id}')
    except Exception as e:
        print(f'Failed to extract article {url_id}: {e}')

print('Data extraction complete.')
