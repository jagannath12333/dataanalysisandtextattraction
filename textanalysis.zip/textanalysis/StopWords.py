import pandas as pd
import requests
from bs4 import BeautifulSoup
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from textstat import flesch_reading_ease, syllable_count

# Download NLTK data
nltk.download('punkt')
nltk.download('stopwords')

# Load input data
input_data = pd.read_excel('Input.xlsx')

# Initialize output data
output_data = []

# Function to clean text
def clean_text(text):
    stop_words = set(stopwords.words('english'))
    words = word_tokenize(text)
    cleaned_words = [word.lower() for word in words if word.isalnum() and word.lower() not in stop_words]
    cleaned_text = ' '.join(cleaned_words)
    return cleaned_text

# Iterate over each row in the input data
for index, row in input_data.iterrows():
    url_id = row['URL_ID']
    url = row['URL']

    # Extract article text from the URL
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')
    article_text = ' '.join([p.get_text() for p in soup.find_all('p')])

    # Clean the article text
    cleaned_text = clean_text(article_text)

    # Perform text analysis
    word_tokens = word_tokenize(cleaned_text)
    total_words = len(word_tokens)
    total_sentences = len(sent_tokenize(cleaned_text))
    avg_sentence_length = total_words / total_sentences
    complex_word_count = sum(1 for word in word_tokens if syllable_count(word) > 2)
    avg_word_length = sum(len(word) for word in word_tokens) / total_words

    # Append the output data
    output_data.append({
        'URL_ID': url_id,
        'URL': url,
        'AVG SENTENCE LENGTH': avg_sentence_length,
        'PERCENTAGE OF COMPLEX WORDS': complex_word_count / total_words,
        'AVG NUMBER OF WORDS PER SENTENCE': total_words / total_sentences,
        'COMPLEX WORD COUNT': complex_word_count,
        'WORD COUNT': total_words,
        'SYLLABLE PER WORD': sum(syllable_count(word) for word in word_tokens) / total_words,
        'AVG WORD LENGTH': avg_word_length
    })

# Create a DataFrame from the output data
output_df = pd.DataFrame(output_data)

# Save the output DataFrame to a CSV file
output_df.to_csv('Output.csv', index=False)
