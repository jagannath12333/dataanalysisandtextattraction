import os
import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
import re

#downloading the neccessary file 
nltk.download('stopwords')
nltk.download('punkt')

# Load stopwords and master dictionary
stop_words = set(stopwords.words('english'))

def load_master_dictionary():
    positive_words = []
    negative_words = []
    with open('MasterDictionary/positive-words.txt', 'r') as file:
        positive_words = file.read().splitlines()
    with open('MasterDictionary/negative-words.txt', 'r') as file:
        negative_words = file.read().splitlines()
    return set(positive_words), set(negative_words)

positive_words, negative_words = load_master_dictionary()

def clean_text(text):
    words = word_tokenize(text.lower())
    words = [word for word in words if word.isalpha() and word not in stop_words]
    return words

def calculate_sentiment_scores(words):
    positive_score = sum(1 for word in words if word in positive_words)
    negative_score = sum(1 for word in words if word in negative_words)
    polarity_score = (positive_score - negative_score) / ((positive_score + negative_score) + 0.000001)
    subjectivity_score = (positive_score + negative_score) / (len(words) + 0.000001)
    return positive_score, negative_score, polarity_score, subjectivity_score

def count_syllables(word):
    return len(re.findall(r'[aeiouy]+', word.lower()))

def calculate_complexity_scores(text):
    sentences = sent_tokenize(text)
    words = word_tokenize(text)
    
    avg_sentence_length = len(words) / len(sentences)
    complex_words = [word for word in words if count_syllables(word) >= 3]
    percentage_complex_words = len(complex_words) / len(words)
    fog_index = 0.4 * (avg_sentence_length + percentage_complex_words)
    avg_words_per_sentence = len(words) / len(sentences)
    complex_word_count = len(complex_words)
    word_count = len(words)
    syllables = sum(count_syllables(word) for word in words)
    syllables_per_word = syllables / len(words)
    
    return (avg_sentence_length, percentage_complex_words, fog_index, 
            avg_words_per_sentence, complex_word_count, word_count, syllables_per_word)

def count_personal_pronouns(text):
    pronouns = re.findall(r'\b(I|we|my|ours|us)\b', text, re.I)
    return len(pronouns)

def calculate_avg_word_length(words):
    return sum(len(word) for word in words) / len(words)

# Load input data
input_data = pd.read_excel('Input.xlsx')

# Prepare a DataFrame for the results
output_columns = ['URL_ID', 'URL', 'POSITIVE SCORE', 'NEGATIVE SCORE', 'POLARITY SCORE',
                  'SUBJECTIVITY SCORE', 'AVG SENTENCE LENGTH', 'PERCENTAGE OF COMPLEX WORDS',
                  'FOG INDEX', 'AVG NUMBER OF WORDS PER SENTENCE', 'COMPLEX WORD COUNT', 
                  'WORD COUNT', 'SYLLABLE PER WORD', 'PERSONAL PRONOUNS', 'AVG WORD LENGTH']
output_data = []

# Read each text file, perform analysis, and store results
for index, row in input_data.iterrows():
    url_id = row['URL_ID']
    file_path = f'extracted_articles/{url_id}.txt'
    
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()
        
        # Clean the text
        words = clean_text(text)
        
        # Calculate sentiment scores
        positive_score, negative_score, polarity_score, subjectivity_score = calculate_sentiment_scores(words)
        
        # Calculate complexity scores
        avg_sentence_length, percentage_complex_words, fog_index, avg_words_per_sentence, complex_word_count, word_count, syllables_per_word = calculate_complexity_scores(text)
        
        # Calculate personal pronouns
        personal_pronouns = count_personal_pronouns(text)
        
        # Calculate average word length
        avg_word_length = calculate_avg_word_length(words)

        # Append results to the output data
        output_data.append([url_id, row['URL'], positive_score, negative_score, polarity_score, 
                            subjectivity_score, avg_sentence_length, percentage_complex_words, fog_index, 
                            avg_words_per_sentence, complex_word_count, word_count, syllables_per_word, 
                            personal_pronouns, avg_word_length])
    else:
        print(f'File not found for URL_ID: {url_id}')

# Convert the output data to a DataFrame
output_df = pd.DataFrame(output_data, columns=output_columns)

# Save the results to an Excel file
output_df.to_excel('Output Data Structure.xlsx', index=False)

print('Text analysis complete.')
